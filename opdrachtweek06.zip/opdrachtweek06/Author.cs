namespace opdrachtweek6
{
   public class Author : Books
    {
        private string name;
		
        private string email;

        private string gender;

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
