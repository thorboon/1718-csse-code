﻿using System;

namespace opdrachtweek6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Opdrachtweek 6!");
        }
    }
}
