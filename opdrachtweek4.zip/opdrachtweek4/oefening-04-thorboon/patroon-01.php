<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="screen.css">
</head>
<body>
   
    <?php
    
    for($i=1;$i<=9;$i++){
        echo '<div class="dotFilled"></div>'.'&nbsp;';
    }

    ?>
</body>

</html>
